// Sonido con Web Audio: efectos y voces originales (WAV) y música de las pistas de audio del CD
"use strict";
(function () {
  const BRR = window.BRR;
  // un valor no finito (NaN) en un parámetro de sonido lanzaba una excepción que paraba la carrera: se ignora
  if (window.AudioParam) for (const k of ['setTargetAtTime', 'setValueAtTime', 'linearRampToValueAtTime', 'exponentialRampToValueAtTime']) { const f = AudioParam.prototype[k];
    if (f) AudioParam.prototype[k] = function (v, ...r) { if (!Number.isFinite(v) || r.some(x => !Number.isFinite(x))) return this; return f.call(this, v, ...r); }; }
  BRR.Audio = class {
    constructor(files) {
      this.files = files; this.cache = new Map(); this.ctx = null;
      // mezcla: general, música, voces, efectos, motores, interfaz (menús) y ambiente
      this.vol = { master: 1, sfx: 0.8, music: 0.6, voice: 1, engine: 0.8, ui: 0.7, amb: 0.6 };
      this.voiceBusyUntil = 0; this.musicSource = 'cd'; this.userTracks = []; this.loops = [];
    }
    init() {
      if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
      const C = window.AudioContext || window.webkitAudioContext; if (!C) return;
      const c = this.ctx = new C(); this.gMaster = c.createGain(); this.gMaster.connect(c.destination);
      const g = (to = this.gMaster) => { const x = c.createGain(); x.connect(to); return x; };
      this.gSfx = g(); this.gMusic = g(); this.gVoice = g(); this.gEngine = g(); this.gUI = g(); this.gAmb = g(); this.gHorn = g(this.gSfx);
      // eco de túnel: envío a una reverberación (respuesta sintética), cuánto según dónde está la cámara
      this.rev = c.createConvolver(); this.rev.buffer = this.impulse(1.6, 2.5); this.revOut = g(); this.revOut.gain.value = 0; this.rev.connect(this.revOut);
      for (const b of [this.gSfx, this.gEngine, this.gAmb]) b.connect(this.rev);
      this.setVolumes(this.vol);
    }
    impulse(sec, decay) { const c = this.ctx, n = Math.floor(c.sampleRate * sec), b = c.createBuffer(2, n, c.sampleRate);
      for (let ch = 0; ch < 2; ch++) { const d = b.getChannelData(ch); for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, decay) * (i < 400 ? i / 400 : 1); } return b; }
    setReverb(k) { if (this.ctx) this.revOut.gain.setTargetAtTime(k * 0.9, this.ctx.currentTime, 0.15); }
    setVolumes(v) { Object.assign(this.vol, v); if (!this.ctx) return; const V = this.vol;
      this.gMaster.gain.value = V.master ?? 1; this.gSfx.gain.value = V.sfx; this.gMusic.gain.value = V.music; this.gVoice.gain.value = V.voice;
      this.gEngine.gain.value = V.engine ?? V.sfx; this.gUI.gain.value = V.ui ?? V.sfx; this.gAmb.gain.value = V.amb ?? V.sfx;
      if (this.stream) this.stream.volume = Math.max(0, Math.min(1, (V.music ?? 1) * (V.master ?? 1) * (this.streamK ?? 1)));
      if ((this.music || this.stream) && V.music <= 0) this.stopMusic(); }
    bus(name) { return { voice: this.gVoice, ui: this.gUI, engine: this.gEngine, amb: this.gAmb, horn: this.gHorn, music: this.gMusic }[name] || this.gSfx; }
    // escucha para el sonido posicional (cámara del jugador); con pantalla partida no hay oyente único: sin panorama
    setListener(pos, fwd, up, on = true) {
      this.spatial = on; if (!this.ctx || !on) return; const L = this.ctx.listener, t = this.ctx.currentTime;
      if (L.positionX) { L.positionX.setTargetAtTime(pos[0], t, 0.02); L.positionY.setTargetAtTime(pos[1], t, 0.02); L.positionZ.setTargetAtTime(pos[2], t, 0.02);
        L.forwardX.setTargetAtTime(fwd[0], t, 0.02); L.forwardY.setTargetAtTime(fwd[1], t, 0.02); L.forwardZ.setTargetAtTime(fwd[2], t, 0.02);
        L.upX.setTargetAtTime(up[0], t, 0.02); L.upY.setTargetAtTime(up[1], t, 0.02); L.upZ.setTargetAtTime(up[2], t, 0.02); }
      else { L.setPosition(...pos); L.setOrientation(...fwd, ...up); }
    }
    panner(pos) { const p = this.ctx.createPanner(); p.panningModel = 'HRTF'; p.distanceModel = 'inverse'; p.refDistance = 6; p.rolloffFactor = 1.1; p.maxDistance = 400; this.movePanner(p, pos); return p; }
    movePanner(p, pos) { if (p.positionX) { const t = this.ctx.currentTime; p.positionX.setTargetAtTime(pos[0], t, 0.03); p.positionY.setTargetAtTime(pos[1], t, 0.03); p.positionZ.setTargetAtTime(pos[2], t, 0.03); } else p.setPosition(...pos); }
    async buf(rel) {
      if (!this.ctx) return null; rel = rel.toUpperCase();
      if (!this.cache.has(rel)) this.cache.set(rel, (async () => {
        const f = this.files.path(rel); if (!f) return null;
        try { return await this.ctx.decodeAudioData(await f.arrayBuffer()); } catch (e) { return null; }
      })());
      return this.cache.get(rel);
    }
    // pos: sonido en un punto del mundo (si hay oyente único); si no, se usa tal cual (con el volumen ya atenuado por distancia)
    async play(rel, { vol = 1, rate = 1, bus = 'sfx', pos = null } = {}) {
      const b = await this.buf(rel); if (!b) return null;
      const s = this.ctx.createBufferSource(), g = this.ctx.createGain(); s.buffer = b; s.playbackRate.value = rate; g.gain.value = vol;
      s.connect(g); let o = g; if (pos && this.spatial) { const p = this.panner(pos); g.connect(p); o = p; }
      o.connect(this.bus(bus)); s.start(); return { s, dur: b.duration / rate };
    }
    async loop(rel, vol = 0, bus = 'sfx', pos = null) {
      const b = await this.buf(rel); if (!b) return null;
      const s = this.ctx.createBufferSource(), g = this.ctx.createGain(); s.buffer = b; s.loop = true; g.gain.value = vol;
      s.connect(g); let p = null; if (pos) { p = this.panner(pos); g.connect(p); p.connect(this.bus(bus)); } else g.connect(this.bus(bus)); s.start();
      return { set: (v, r, at) => { const t = this.ctx.currentTime; if (Number.isFinite(v)) g.gain.setTargetAtTime(v, t, 0.05); if (r && Number.isFinite(r)) s.playbackRate.setTargetAtTime(r, t, 0.05); if (at && at.every && !at.every(Number.isFinite)) at = null; if (p && at) this.movePanner(p, at); }, stop: () => { try { s.stop(); } catch (e) { } } };
    }
    // motor con dos capas de la misma muestra: una grave (a media velocidad, filtrada) que manda a bajas vueltas y la normal arriba,
    // un filtro que se abre al acelerar (al soltar suena ahogado) y una leve vibración; así los cambios de régimen suenan suaves
    async engine(rel, bus = 'engine') {
      const b = await this.buf(rel); if (!b) return null; const c = this.ctx, mk = () => { const s = c.createBufferSource(); s.buffer = b; s.loop = true; s.loopStart = 0; s.loopEnd = b.duration; return s; };
      const s1 = mk(), s2 = mk(), g1 = c.createGain(), g2 = c.createGain(), lp = c.createBiquadFilter(), lp2 = c.createBiquadFilter(), out = c.createGain();
      lp.type = 'lowpass'; lp.frequency.value = 2400; lp.Q.value = 0.5; lp2.type = 'lowpass'; lp2.frequency.value = 900; g1.gain.value = 0; g2.gain.value = 0; out.gain.value = 0;
      s1.connect(lp2); lp2.connect(g1); s2.connect(g2); g1.connect(lp); g2.connect(lp); lp.connect(out); out.connect(this.bus(bus));
      try { s2.start(0, b.duration * 0.37); } catch (e) { s2.start(); } s1.start();
      const lfo = c.createOscillator(), lg = c.createGain(); lfo.frequency.value = 7; lg.gain.value = 0.012; lfo.connect(lg); lg.connect(s2.playbackRate); lg.connect(s1.playbackRate); lfo.start();
      return { set: (v, r, thr = 0.5) => { const t = c.currentTime, x = Math.max(0, Math.min(1, (r - 0.8) / 1.1));
          out.gain.setTargetAtTime(v, t, 0.06); g1.gain.setTargetAtTime(0.9 * (1 - x) + 0.1, t, 0.08); g2.gain.setTargetAtTime(0.35 + 0.65 * x, t, 0.08);
          s1.playbackRate.setTargetAtTime(r * 0.62, t, 0.07); s2.playbackRate.setTargetAtTime(r, t, 0.07); lp.frequency.setTargetAtTime(900 + 3200 * thr + 1500 * x, t, 0.1); lfo.frequency.setTargetAtTime(5 + 9 * x, t, 0.2); },
        stop: () => { for (const n of [s1, s2, lfo]) try { n.stop(); } catch (e) { } } };
    }
    // motor de cuatro cilindros japonés de altas vueltas (Cívico), sintetizado: grave y redondo abajo y, al pasar de unas 5.500 rpm,
    // entra la leva "de arriba": más agudo, más metálico y con más volumen, hasta el corte a 8.200
    vtec(bus = 'engine', pos = null) {
      if (!this.ctx) return null; const c = this.ctx;
      const O = ['sawtooth', 'sawtooth', 'square', 'sawtooth'].map(t => { const o = c.createOscillator(); o.type = t; return o; }), Gn = O.map(() => c.createGain());
      const ws = c.createWaveShaper(), cur = new Float32Array(1024); for (let i = 0; i < 1024; i++) { const x = i / 512 - 1; cur[i] = Math.tanh(x * 2.4) * 0.9; } ws.curve = cur;
      const mix = c.createGain(); mix.gain.value = 0.5; const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 900; lp.Q.value = 1.4; const pk = c.createBiquadFilter(); pk.type = 'peaking'; pk.frequency.value = 2600; pk.Q.value = 1.2; pk.gain.value = 0;
      const hp = c.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 55; const out = c.createGain(); out.gain.value = 0;
      O.forEach((o, i) => { o.connect(Gn[i]); Gn[i].connect(mix); }); mix.connect(ws); ws.connect(lp); lp.connect(pk); pk.connect(hp); hp.connect(out);
      let pn = null; if (pos && this.spatial) { pn = this.panner(pos); out.connect(pn); pn.connect(this.bus(bus)); } else out.connect(this.bus(bus));
      const jit = c.createOscillator(), jg = c.createGain(); jit.frequency.value = 9; jg.gain.value = 0.8; jit.connect(jg); for (const o of O) jg.connect(o.frequency);
      for (const o of [...O, jit]) o.start();
      return { set: (v, r, x) => { const t = c.currentTime, thr = Array.isArray(x) ? 0.8 : (x ?? 0.5), k = Math.max(0, Math.min(1, (r - 0.8) / 1.1)), f = 30 + 243 * k, u = Math.max(0, Math.min(1, (k - 0.6) / 0.08)), vt = u * u * (3 - 2 * u) * (0.35 + 0.65 * thr);   // encendidos por segundo: ralentí ~900 rpm, corte ~8.200
          out.gain.setTargetAtTime(v * (0.62 + 0.3 * vt), t, 0.05); [f, f * 0.5, f * 2, f * 4].forEach((ff, i) => O[i].frequency.setTargetAtTime(ff, t, 0.04));
          Gn[0].gain.setTargetAtTime(0.5, t, 0.05); Gn[1].gain.setTargetAtTime(0.4 * (1 - 0.6 * vt), t, 0.05); Gn[2].gain.setTargetAtTime(0.1 + 0.34 * vt, t, 0.04); Gn[3].gain.setTargetAtTime(0.26 * vt, t, 0.04);
          lp.frequency.setTargetAtTime(650 + 1900 * thr + 1100 * k + 3200 * vt, t, 0.05); lp.Q.setTargetAtTime(1.4 + 2.2 * vt, t, 0.05); pk.gain.setTargetAtTime(9 * vt, t, 0.05); jg.gain.setTargetAtTime(0.5 + 2 * (1 - thr), t, 0.1);
          if (pn && Array.isArray(x)) this.movePanner(pn, x); },
        stop: () => { for (const n of [...O, jit]) try { n.stop(); } catch (e) { } } };
    }
    // motor de dos tiempos (go-kart) sintetizado: zumbido rasposo y agudo, con explosiones a la frecuencia del cigüeñal y algo de ruido de escape
    twoStroke(bus = 'engine', pos = null) {
      if (!this.ctx) return null; const c = this.ctx;
      if (!this._nz) { const n = c.sampleRate * 1.5 | 0, b = c.createBuffer(1, n, c.sampleRate), d = b.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1; this._nz = b; }
      const o1 = c.createOscillator(), o2 = c.createOscillator(), o3 = c.createOscillator(); o1.type = 'sawtooth'; o2.type = 'square'; o3.type = 'sawtooth';
      const g1 = c.createGain(), g2 = c.createGain(), g3 = c.createGain(); g1.gain.value = 0.55; g2.gain.value = 0.25; g3.gain.value = 0.18;
      const nz = c.createBufferSource(); nz.buffer = this._nz; nz.loop = true; const nbp = c.createBiquadFilter(); nbp.type = 'bandpass'; nbp.frequency.value = 2200; nbp.Q.value = 0.9;
      const am = c.createGain(); am.gain.value = 0; const amO = c.createOscillator(); amO.type = 'square'; const amG = c.createGain(); amG.gain.value = 0.5; amO.connect(amG); amG.connect(am.gain);   // el ruido "pedorrea" a la frecuencia de las explosiones
      const ws = c.createWaveShaper(), cur = new Float32Array(1024); for (let i = 0; i < 1024; i++) { const x = i / 512 - 1; cur[i] = Math.tanh(x * 3.2) * 0.9; } ws.curve = cur;
      const mix = c.createGain(); mix.gain.value = 0.5; const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 3000; lp.Q.value = 2.2; const hp = c.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 70;
      const out = c.createGain(); out.gain.value = 0;
      o1.connect(g1); o2.connect(g2); o3.connect(g3); g1.connect(mix); g2.connect(mix); g3.connect(mix); nz.connect(nbp); nbp.connect(am); am.connect(mix); mix.connect(ws); ws.connect(lp); lp.connect(hp); hp.connect(out);
      let pn = null; if (pos && this.spatial) { pn = this.panner(pos); out.connect(pn); pn.connect(this.bus(bus)); } else out.connect(this.bus(bus));
      const jit = c.createOscillator(), jg = c.createGain(); jit.frequency.value = 11; jg.gain.value = 1.5; jit.connect(jg); for (const o of [o1, o2, o3, amO]) jg.connect(o.frequency);   // irregularidad del dos tiempos
      for (const n of [o1, o2, o3, amO, jit]) n.start(); nz.start();
      return { set: (v, r, x) => { const t = c.currentTime, thr = Array.isArray(x) ? 0.8 : (x ?? 0.5), k = Math.max(0, Math.min(1, (r - 0.8) / 1.1)), f = 38 + 175 * k;   // ralentí ~2.300 rpm, arriba ~13.000
          out.gain.setTargetAtTime(v * 0.75, t, 0.05); o1.frequency.setTargetAtTime(f, t, 0.04); o2.frequency.setTargetAtTime(f * 2.01, t, 0.04); o3.frequency.setTargetAtTime(f * 3.02, t, 0.04); amO.frequency.setTargetAtTime(f, t, 0.04);
          am.gain.setTargetAtTime(0.25 + 0.5 * thr, t, 0.05); lp.frequency.setTargetAtTime(1200 + 3600 * thr + 1500 * k, t, 0.06); jg.gain.setTargetAtTime(1 + 4 * (1 - thr), t, 0.1);
          if (pn && Array.isArray(x)) this.movePanner(pn, x); },
        stop: () => { for (const n of [o1, o2, o3, amO, jit, nz]) try { n.stop(); } catch (e) { } } };
    }
    // derrape de neumático "de verdad" (Grand Prix, F1, karting y drift): chirrido tonal que cambia solo de tono y de fuerza + soplido de goma; cada uno distinto
    skid(bus = 'sfx') {
      if (!this.ctx) return null; const c = this.ctx;
      if (!this._nz) { const n = c.sampleRate * 1.5 | 0, b = c.createBuffer(1, n, c.sampleRate), d = b.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1; this._nz = b; }
      const base = 720 + Math.random() * 380, nz = c.createBufferSource(); nz.buffer = this._nz; nz.loop = true; nz.playbackRate.value = 0.9 + Math.random() * 0.2;
      const b1 = c.createBiquadFilter(), b2 = c.createBiquadFilter(), b3 = c.createBiquadFilter(), hiss = c.createBiquadFilter(); b1.type = b2.type = b3.type = 'bandpass'; b1.Q.value = 28; b2.Q.value = 22; b3.Q.value = 16; hiss.type = 'highpass'; hiss.frequency.value = 2500;
      b1.frequency.value = base; b2.frequency.value = base * 2.03; b3.frequency.value = base * 3.1;
      const s1 = c.createOscillator(); s1.type = 'triangle'; s1.frequency.value = base; const sg = c.createGain(); sg.gain.value = 0;
      const gb1 = c.createGain(), gb2 = c.createGain(), gb3 = c.createGain(), gh = c.createGain(); gb1.gain.value = 9; gb2.gain.value = 5; gb3.gain.value = 3; gh.gain.value = 0.18;
      const out = c.createGain(); out.gain.value = 0;
      nz.connect(b1); nz.connect(b2); nz.connect(b3); nz.connect(hiss); b1.connect(gb1); b2.connect(gb2); b3.connect(gb3); hiss.connect(gh); s1.connect(sg);
      for (const g of [gb1, gb2, gb3, gh, sg]) g.connect(out); out.connect(this.bus(bus)); nz.start(); s1.start();
      let nextT = 0, lastV = 0;
      return { set: (v, rate = 1) => { const t = c.currentTime;
          if (t > nextT) { nextT = t + 0.08 + Math.random() * 0.25; const f = base * rate * (0.88 + Math.random() * 0.24);   // el tono va cambiando (la goma "canta" distinto según agarra)
            for (const [b, m] of [[b1, 1], [b2, 2.03], [b3, 3.1]]) b.frequency.setTargetAtTime(f * m, t, 0.06); s1.frequency.setTargetAtTime(f, t, 0.05);
            sg.gain.setTargetAtTime(v * (0.02 + Math.random() * 0.05), t, 0.05); gh.gain.setTargetAtTime(0.12 + Math.random() * 0.12, t, 0.08); }
          const wob = v > 0.02 ? 0.75 + Math.random() * 0.5 : 1; out.gain.setTargetAtTime(v * 0.9 * wob, t, v > lastV ? 0.04 : 0.09); lastV = v; },
        stop: () => { for (const n of [nz, s1]) try { n.stop(); } catch (e) { } } };
    }
    // ambiente: viento según la velocidad (ruido filtrado), en su propio canal
    ambient() {
      if (!this.ctx || this.amb) return this.amb; const c = this.ctx, n = c.sampleRate * 2, b = c.createBuffer(1, n, c.sampleRate), d = b.getChannelData(0);
      let last = 0; for (let i = 0; i < n; i++) { last = last * 0.98 + (Math.random() * 2 - 1) * 0.02; d[i] = last * 6; }
      const s = c.createBufferSource(); s.buffer = b; s.loop = true; const f = c.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 500; f.Q.value = 0.6;
      const g = c.createGain(); g.gain.value = 0; s.connect(f); f.connect(g); g.connect(this.gAmb); s.start();
      return this.amb = { set: (v, fr) => { const t = c.currentTime; g.gain.setTargetAtTime(v, t, 0.2); f.frequency.setTargetAtTime(fr, t, 0.2); } };
    }
    // turbo: soplido sintetizado (ruido que barre de grave a agudo + golpe grave), sale también en los rivales con su posición
    boost(vol = 0.8, pos = null) {
      if (!this.ctx) return; const c = this.ctx, t = c.currentTime, dur = 1.3;
      if (!this._nz) { const n = c.sampleRate * 1.5 | 0, b = c.createBuffer(1, n, c.sampleRate), d = b.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1; this._nz = b; }
      const s = c.createBufferSource(); s.buffer = this._nz; const f = c.createBiquadFilter(); f.type = 'bandpass'; f.Q.value = 1.3;
      f.frequency.setValueAtTime(350, t); f.frequency.exponentialRampToValueAtTime(2600, t + 0.35); f.frequency.exponentialRampToValueAtTime(900, t + dur);
      const g = c.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.05); g.gain.exponentialRampToValueAtTime(vol * 0.35, t + 0.5); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      const o = c.createOscillator(); o.type = 'sawtooth'; o.frequency.setValueAtTime(70, t); o.frequency.exponentialRampToValueAtTime(140, t + 0.4);
      const og = c.createGain(); og.gain.setValueAtTime(0.0001, t); og.gain.exponentialRampToValueAtTime(vol * 0.5, t + 0.03); og.gain.exponentialRampToValueAtTime(0.0001, t + 0.6);
      const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 400;
      s.connect(f); f.connect(g); o.connect(lp); lp.connect(og); const out = c.createGain(); g.connect(out); og.connect(out);
      if (pos && this.spatial) { const p = this.panner(pos); out.connect(p); p.connect(this.bus('sfx')); } else out.connect(this.bus('sfx'));
      s.start(t); s.stop(t + dur + 0.05); o.start(t); o.stop(t + 0.7);
    }
    // bocina sintetizada sencilla (rivales): ver horns.js para todas las demás
    horn(pitch = 1, vol = 0.5, dur = null, type = 'normal', pos = null) {
      const h = BRR.playHorn ? BRR.playHorn(this, type, pitch, vol, { dur, pos }) : null; return h || { stop() { } };
    }
    // voces del comentarista: una a la vez, con pausa mínima entre frases y sin repetir la misma categoría seguido
    async voice(rel, force = false) {
      if (!this.ctx) return; const now = this.ctx.currentTime, cat = rel.split('/').pop().replace(/\d*\.WAV$/i, '');
      this.catT = this.catT || {};
      if (!force && (now < this.voiceBusyUntil || now < (this.catT[cat] || 0))) return;
      this.voiceBusyUntil = now + 4; this.catT[cat] = now + 15;
      const r = await this.play(rel, { bus: 'voice' }); if (r) this.voiceBusyUntil = now + r.dur + 4;
    }
    stopAll() { for (const l of this.loops || []) l && l.stop(); this.loops = []; if (this.amb) this.amb.set(0, 500); this.setReverb(0); }

    // ---------- música del CD (pistas de audio de la imagen .cue/.img) ----------
    cdTracks() {
      if (this._cd !== undefined) return this._cd;
      this._cd = null; const cue = this.files.list('.CUE')[0]; if (!cue) return null;
      return this._cd = (async () => {
        const txt = BRR.text(await this.files.bytes(cue)); let fileName = null, cur = null; const tracks = [];
        for (const l of txt.split(/\r?\n/)) {
          let m;
          if ((m = l.match(/FILE\s+"([^"]+)"/i))) fileName = m[1].toUpperCase().split(/[\\/]/).pop();
          else if ((m = l.match(/TRACK\s+(\d+)\s+(\S+)/i))) tracks.push(cur = { n: +m[1], type: m[2].toUpperCase(), idx: {} });
          else if ((m = l.match(/INDEX\s+(\d+)\s+(\d+):(\d+):(\d+)/i)) && cur) cur.idx[+m[1]] = ((+m[2] * 60 + +m[3]) * 75 + +m[4]) * 2352;
        }
        const img = fileName && this.files.files.get(fileName); if (!img) return null;
        const audio = [];
        tracks.forEach((t, i) => {
          if (t.type !== 'AUDIO' || t.idx[1] === undefined) return;
          const nx = tracks[i + 1], end = nx ? (nx.idx[0] ?? nx.idx[1]) : img.size;
          audio.push({ n: t.n, start: t.idx[1], end });
        });
        return { img, audio };
      })();
    }
    // pista de audio del CD por número (como en TOURN.TXT); loop para música, sin loop para las presentaciones habladas
    async cdBuffer(n) {
      const cd = await this.cdTracks(); if (!cd) return null;
      const tr = cd.audio.find(t => t.n === n); if (!tr) return null;
      this.cdCache = this.cdCache || new Map();
      if (!this.cdCache.has(n)) this.cdCache.set(n, (async () => {
        const raw = new Int16Array(await cd.img.slice(tr.start, tr.end - ((tr.end - tr.start) % 4)).arrayBuffer());
        const k = raw.length / 2; if (k < 1) return null;   // pista vacía en la imagen del CD (aviso #13)
        const b = this.ctx.createBuffer(2, k, 44100), L = b.getChannelData(0), Rr = b.getChannelData(1);
        for (let i = 0; i < k; i++) { L[i] = raw[2 * i] / 32768; Rr[i] = raw[2 * i + 1] / 32768; }
        if (this.cdCache.size > 6) this.cdCache.delete(this.cdCache.keys().next().value);
        return b;
      })());
      return this.cdCache.get(n);
    }
    // música propia del jugador (lista de reproducción): suena en orden, una tras otra
    async playUser() {
      if (!this.userTracks.length) return false; if (this.musicTrack === 'u' && this.music) return 'u';
      this.stopMusic(); const token = this.musicToken = Symbol(); this.userIdx = ((this.userIdx ?? -1) + 1) % this.userTracks.length;
      let b = null; try { b = await this.ctx.decodeAudioData(await this.userTracks[this.userIdx].blob.arrayBuffer()); } catch (e) { }
      if (!b || token !== this.musicToken) return false;
      const s = this.ctx.createBufferSource(); s.buffer = b; s.connect(this.gMusic); s.start(); this.music = s; this.musicTrack = 'u';
      s.onended = () => { if (this.music === s) { this.music = null; this.musicTrack = null; this.playUser(); } }; return 'u';
    }
    async playTrack(n) {
      if (this.musicSource === 'off') { this.stopMusic(); return false; }
      if (this.musicSource === 'mias' && this.userTracks.length) return this.playUser();
      if (this.musicTrack === n && this.music) return n;
      this.stopMusic(); if (!this.ctx || this.vol.music <= 0) return false;
      const token = this.musicToken = Symbol(), b = await this.cdBuffer(n);
      if (!b || token !== this.musicToken) return false;
      const s = this.ctx.createBufferSource(); s.buffer = b; s.loop = true; s.connect(this.gMusic); s.start();
      this.music = s; this.musicTrack = n; return n;
    }
    async narrate(n) {   // presentación hablada del circuito (pista corta del CD), baja la música mientras habla
      this.stopNarration(); if (!this.ctx) return;
      const token = this.narToken = Symbol(), b = await this.cdBuffer(n);
      if (!b || token !== this.narToken) return;
      const s = this.ctx.createBufferSource(); s.buffer = b; s.connect(this.gVoice); s.start(); this.nar = s;
      const t = this.ctx.currentTime; this.gMusic.gain.setTargetAtTime(this.vol.music * 0.3, t, 0.2);
      s.onended = () => { if (this.nar === s) { this.nar = null; this.gMusic.gain.setTargetAtTime(this.vol.music, this.ctx.currentTime, 0.4); } };
    }
    stopNarration() { this.narToken = null; if (this.nar) { try { this.nar.stop(); } catch (e) { } this.nar = null; if (this.ctx) this.gMusic.gain.setTargetAtTime(this.vol.music, this.ctx.currentTime, 0.2); } }
    async playMusic(seed) {
      if (this.musicSource === 'off') return false;
      if ((this.musicSource === 'mias' || (this.musicSource === 'mezcla' && Math.random() < 0.5)) && this.userTracks.length) { this.stopMusic(); return this.playUser(); }
      const cd = await this.cdTracks(); if (!cd || !cd.audio.length) return false;
      const longs = cd.audio.filter(t => t.end - t.start > 44100 * 4 * 60);   // solo pistas largas (música)
      const l = longs.length ? longs : cd.audio;
      return this.playTrack(l[((seed % l.length) + l.length) % l.length].n);
    }
    // música larga de un modo (Grand Prix, drift): se reproduce en streaming (sin decodificarla entera) y en bucle
    playStream(url, k = 1) { this.stopMusic(); if (!this.ctx || this.vol.music <= 0) return false; const a = new Audio(url); a.loop = true; this.streamK = k; a.volume = Math.max(0, Math.min(1, (this.vol.music ?? 1) * (this.vol.master ?? 1) * k)); a.play().catch(() => { }); this.stream = a; this.musicTrack = 'stream'; return url; }
    stopMusic() { if (this.stream) { try { this.stream.pause(); } catch (e) { } this.stream = null; } this.musicToken = null; this.musicTrack = null; if (this.music) { const m = this.music; this.music = null; try { m.onended = null; m.stop(); } catch (e) { } } }
  };
})();
