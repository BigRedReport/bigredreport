window.BRR.VERSION = '0.70.0';
