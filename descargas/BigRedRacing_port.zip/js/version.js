window.BRR.VERSION = '0.73.0';
