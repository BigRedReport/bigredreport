window.BRR.VERSION = '0.74.0';
